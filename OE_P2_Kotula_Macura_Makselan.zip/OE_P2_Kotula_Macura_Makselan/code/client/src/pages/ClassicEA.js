import Form from "../components/Form";

const ClassicEA = () => {

    return (
        <div className="home-page">
            <h1>Classic EA</h1>
            <Form/>
        </div>
    );
}

export default ClassicEA;