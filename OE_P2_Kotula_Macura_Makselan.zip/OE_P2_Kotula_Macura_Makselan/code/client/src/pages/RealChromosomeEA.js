import FormRealChromosome from "../components/FormRealChromosome";

const ClassicEA = () => {

    return (
        <div className="home-page">
            <h1>Classic EA - real chromosome</h1>
            <FormRealChromosome/>
        </div>
    );
}

export default ClassicEA;