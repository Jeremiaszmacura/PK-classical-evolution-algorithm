const HomePage = () => {

    return (
        <div className="home-page">
            <h1>Evolutionary Computing</h1>
            <h2>Cracow University of Technology</h2>
        </div>
        
    );
}

export default HomePage;