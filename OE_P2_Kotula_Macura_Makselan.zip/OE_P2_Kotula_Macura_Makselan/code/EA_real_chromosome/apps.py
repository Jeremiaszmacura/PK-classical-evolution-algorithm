from django.apps import AppConfig


class EaRealChromosomeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'EA_real_chromosome'
